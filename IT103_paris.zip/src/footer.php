    <div class="container">
        <hr>
        <!-- Footer -->
        <footer>
            <div class="row">
                <div class="col-lg-12">
                    <p><?php echo siteTitle().'. Copyright Salino & Priou.' ?></p>
                </div>
            </div>
        </footer>
    </div>
</body>
</html>


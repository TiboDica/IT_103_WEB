<?php

// Database configuration
$GLOBALS['dbServ'] = 'localhost';
$GLOBALS['dbUser'] = 'root';
$GLOBALS['dbPass'] = 'root';
$GLOBALS['dbName'] = 'online_bet';

// Site configuration
$GLOBALS['siteTitle'] = 'EZ Money 3000 - Online Bet Corporation';

// Bet configuration
$GLOBALS['initialOdd'] = '1';
$GLOBALS['limitingFactor'] = '1.3';

?>
